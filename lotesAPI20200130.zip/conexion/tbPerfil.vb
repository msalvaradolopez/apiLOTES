﻿Public Class tbPerfil
    Public IDROL As String
    Public NOMBRE As String
End Class
