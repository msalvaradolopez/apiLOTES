﻿Public Class tbUsuario
    Public CODE As String
    Public IDROL As String
    Public PASSW As String
End Class
