﻿Public Class tbLote
    Public IDMOV As Integer
    Public U_SO1_NUMEROARTICULO As String
    Public U_SO1_FOLIO As String
    Public U_SO1_NUMPARTIDA As Integer
    Public IDLOTE As String
    Public ALMACEN As String
    Public TIPOMOV As String
    Public DOCTO As String
    Public FECHADOC As String
    Public SOCIO As String
    Public VENDEDOR As String
    Public CANTIDAD As Decimal
    Public EXISTENCIA As Decimal
    Public UBICACION As String
    Public USUARIO_R1 As String
    Public USERID As String
    Public FECHAMOV As String
    Public CONS As Integer
    Public IMPRIMIR As String
    Public ItemName As String
    Public UNIDAD As String
    Public IDMOVORIGEN As Integer
End Class
