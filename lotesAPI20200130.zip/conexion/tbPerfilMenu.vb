﻿Public Class tbPerfilMenu
    Public IDROL As String
    Public ORDEN As Integer
    Public IDMENU As String
    Public NOMBRE As String
End Class
