﻿Public Class tbMensaje
    Public codigo As Integer ' -1: Error, 0: ok
    Public mensaje As String
End Class
