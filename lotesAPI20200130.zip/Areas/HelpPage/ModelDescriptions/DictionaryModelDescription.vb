Namespace Areas.HelpPage.ModelDescriptions
    Public Class DictionaryModelDescription
        Inherits KeyValuePairModelDescription
    End Class
End Namespace