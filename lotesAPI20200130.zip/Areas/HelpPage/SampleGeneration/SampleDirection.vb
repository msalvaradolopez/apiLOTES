Namespace Areas.HelpPage
    ''' <summary>
    ''' Indicates whether the sample is used for request or response
    ''' </summary>
    Public Enum SampleDirection
        Request = 0
        Response
    End Enum
End Namespace